package absyn;

abstract public class Dec extends Absyn{

}